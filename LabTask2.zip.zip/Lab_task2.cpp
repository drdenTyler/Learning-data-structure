#include<iostream>
using namespace std;
int main()
{
    int Array_1[5] = {10,20,30,40,50};
    int Array_2[8] = {1,2,3,4,5,6,9,7};
    int Merged_Array[13];
    int i, k;
    cout<<"First Array: ";
    for(i=0; i<5; i++)
    {
        cout<<Array_1[i]<<endl;
        Merged_Array[i] = Array_1[i];
    }
    k=i;
    cout<<"Second Array: ";
    for(i=0; i<8; i++)
    {
        cout<<Array_2[i]<<endl;
        Merged_Array[k] = Array_2[i];
        k++;

    }

    cout<<endl<<"The merged reversed array: ";
    for(i=12; i>=0; --i)
    {
        cout<<Merged_Array[i]<<" ";

    }
    if(Array_1[i]==Array_2[k])
    {
        cout<<endl<<"Common elements: "<<Merged_Array[k];
    }
    else{
        cout<<"No common";
    }



return 0;
}
