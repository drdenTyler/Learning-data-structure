#include<iostream>
using namespace std;
int main()
{
    int arr[6];
    int i;
    cout<<"Enter the elements of array: ";
    for (i=0; i<6; i++)
    {
        cin>>arr[i];
        if(arr[i]!=i)
            cout<<"Unique array"<<endl;
    }
return 0;
}
