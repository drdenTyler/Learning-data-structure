#include<iostream>
using namespace std;
int main()
{
    int a1[6]= {1,4,6,3,7,9};
    int a2[6] = {5,12,6,3,11,10};
    int b[12];
    int i, k;
    cout<<"First Array: ";
    for(i=0; i<6; i++)
    {
        b[i]= a1[i];
        cout<<a1[i]<<endl;

    }
    k=i;
    cout<<"Second Array: ";
    for(i=0; i<6; i++)
    {
        b[k]=a2[i];
        cout<<a2[i]<<endl;

    }

    for(i=0; i<k; i++)
    {
         if(a1[i]==a2[i])
        {


        }
        else{
            cout<<"No common elements!";
        }
    }





return 0;
}
