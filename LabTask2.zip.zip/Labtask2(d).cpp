#include<iostream>
using namespace std;
int main()
{
    int arr[10]= {8,4,6,1,6,9,6,1,9,8};
    int t;
    int count = 0;
    cout<<"Enter integer to be searched: ";
    cin>>t;

    for(int i=0; i<10; i++)
    {
        if(arr[i]==t)
        {
            count++;
        }
    }

    cout<<"The integer "<<t<<" occurs "<<count<<" times.";
return 0;
}
